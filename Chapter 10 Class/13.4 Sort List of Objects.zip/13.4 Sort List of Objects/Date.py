# Date.py
# Author: RoxAnn H. Stalvey
# Modified by Pharr to include compareTo

class Date:
    def __init__(self): #default constructor sets date to 1-1-2000
        self.month = 1
        self.day = 1
        self.year = 2000

    def getMonth(self):
        return self.month

    def getDay(self):
        return self.day

    def getYear(self):
        return self.year

    def setDate(self, mthParm, dayParm, yrParm):  	
  	#call to validDay method to make certain values passed to setDate
  	#represent valid dates.
        if self.validYear(yrParm):
            self.year = yrParm
            if self.validMonth(mthParm):
                self.month = mthParm
                if self.validDay(mthParm, dayParm, yrParm):
                    self.day = dayParm
                else:
                    msg = "The number of days given, " + str(dayParm)
                    msg = msg + ", is not valid for the month " + str(mthParm)
                    print (msg)
            else:
                print ("Month must be between 1 and 12")
        else:
            print ("Year must be greater than -1")

    def validMonth(self,mth):
        return mth>=1 and mth<=12

    def validYear(self, yr):
        return yr >= 0

    #method for determining if date input is valid
    def validDay (self, mth, day, yr):
        valid = day >= 1
        if valid:
            if mth in [1, 3, 5, 7, 8, 10, 12]:
                valid = day <= 31
            elif mth in [4, 6, 9, 11]:
                valid = day <= 30
            else:
                #must consider year for Feb.
                if (yr % 400 == 0 or (yr % 100 !=0 and yr % 4==0)): #leap year
                    valid = day <= 29
                else: #not a leap year
                    valid = day <=28      
        return valid
  
    ##
    ## compareTo(self, otherDate) -> boolean
    ## returns 0 if self and otherDate are equal
    ## returns negative value if self occurred before otherDate
    ## returns positive value if self occurred after otherDate
    ##
    def compareTo(self, otherDate):
        comp = self.year - otherDate.year
        if comp == 0:
            comp = self.month - otherDate.month
            if comp == 0:
                comp = self.day - otherDate.day
        return comp

    def __str__(self):
        return str(self.month) + "/" + str(self.day) + "/" + str(self.year)
  
  
