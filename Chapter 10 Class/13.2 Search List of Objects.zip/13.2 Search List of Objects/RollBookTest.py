# RollBookTest.py
# Author: Pharr

# RollBookDriver - creates a RollBook object and inserts Students

from RollBook import RollBook
from Student import Student
from Date import Date

def main():
    roll = RollBook("CSCI220", "Programming I", "Fall 2012")
    print ("When roll book is empty...")
    print (roll)
    print ("Class Average:", roll.classAverage())
    print ("\n*****\n")
    
    print ("Adding students 123, 234, 345, 456")
    print ()
    d1 = Date ()
    d1.setDate(8,15,2006)
    stu1 = Student(123, "Chad", "Cheddar", [90, 93], d1)
    roll.addStudent(stu1)
    
    d2 = Date()
    d2.setDate(5, 12, 2000)
    stu2 = Student(234, "Brad", "Brie", [95, 90, 92], d2)
    roll.addStudent(stu2)
    
    d3 = Date()
    d3.setDate(12, 1, 2004)
    stu3 = Student(345, "Tradd", "Tilsit", [], d3)
    roll.addStudent(stu3)

    d4 = Date()
    d4.setDate(3, 9, 2007)
    stu4 = Student(456, "Vlad", "Velveeta", [87, 92, 98, 94, 92], d4)
    roll.addStudent(stu4)

    print (roll)
    print ("*****\n")

    print ("Looking for students 456, 345, 999, 234, 123")
    print ()
    print (roll.displayStudent(456))
    print ()
    print (roll.displayStudent(345))
    print ()
    print (roll.displayStudent(999))
    print ()
    print (roll.displayStudent(234))
    print ()
    print (roll.displayStudent(123))
    print ()

    roll.addGrade(345, 93)
    roll.addGrade(345, 89)
    roll.addGrade(345, 97)
    print ("After adding grades 93, 89, 97 to student 345:")

    print (roll.displayStudent(345))
    print ()


    print ("Class Average:", roll.classAverage())
    

main()
