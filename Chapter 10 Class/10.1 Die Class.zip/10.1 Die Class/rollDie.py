# rollDie.py

# Creates a single die object, then rolls it for each <enter>
# until user says "no".

from Die import Die

def main():
    theDie = Die()

    go = input("Roll the die? <enter> for yes, 'no' to stop: ")

    while go == "":
        theDie.roll()
        print ("die =", theDie.getValue())
        go = input("Roll the die? <enter> for yes, 'no' to stop: ")


##    theDie.setValue(0)
##    print theDie.getValue()

main()
