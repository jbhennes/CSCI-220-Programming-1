# Student class
# Student's data members: firstName, lastName, list of grades
# Author: RoxAnn H. Stalvey

class Student:

    def __init__(self, firstName, lastName, grades):
        self.firstName = firstName
        self.lastName = lastName
        self.grades = []
        for grade in grades:
            self.grades.append(grade)

    def addGrade(self, grade):
        self.grades.append(grade)

    def getFirstName(self):
        return self.firstName

    def getLastName(self):
        return self.lastName

    def getGrades(self):
        return self.grades

    def setFirstName(self, firstName):
        self.firstName = firstName

    def setLastName(self, lastName):
        self.lastName = lastName

    def setGrades(self, grades):
        self.grades = []
        for grade in grades:
            self.grades.append(grade)

    def calcAvg(self):
        total = 0.0
        count = len(self.grades)
        for grade in self.grades:
            total = total + grade
        if count == 0:
            avg = -1
        else:
            avg = total / count
        return avg

    def __str__(self):
        msg = "Student: " + self.getFirstName() + " " + self.getLastName()
        msg = msg + "\nGrades: " + str(self.getGrades())
        msg = msg + "\nAverage: %0.3f"  % self.calcAvg()
        return msg
    
