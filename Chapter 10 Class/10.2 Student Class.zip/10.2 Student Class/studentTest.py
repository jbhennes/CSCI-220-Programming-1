# studentTest - creates Student objects and tests Student methods
# Author: RoxAnn H. Stalvey

from Student import Student

def main():
    chad = Student("Chad", "Cheddar", [90, 93])
    chad.addGrade(93)
    chad.addGrade(89)
    chad.addGrade(97)
    print (chad.getFirstName() + "'s grades are: " + str(chad.getGrades()))
    print ("Average: " + str(chad.calcAvg()))
    
    brad = Student("Brad", "Brie", [95, 90, 92])
    print ()
    print (brad) #What is this printing?
    
    csci220 = []
    csci220.append(chad)
    csci220.append(brad)
    csci220.append(Student("Tradd", "Tilsit", []))
    csci220.append(Student("Vlad", "Velveeta", [87, 92, 98, 94, 92]))

##    print ("\n************************\n")
##    for student in csci220:
##        print (student)
##        print ()

main()
